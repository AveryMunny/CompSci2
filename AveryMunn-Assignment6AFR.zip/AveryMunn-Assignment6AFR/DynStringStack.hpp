
#ifndef DYNSTRINGSTACK_HPP
#define DYNSTRINGSTACK_HPP

#include <iostream>
using std::string;

class DynStringStack
{
private:
	struct StackNode
	{
		string value; //value in the node
		StackNode* next; //pointer in the next node
	};
	StackNode* top; //pointer to stack top

public:
	DynStringStack() { top = nullptr; }
	~DynStringStack();
	void push(string);
	string pop();
	bool isEmpty();

};

#endif  //DYNSTRINGSTACK_H