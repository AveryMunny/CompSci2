#ifndef TAXCONSTANTS_HPP
#define TAXCONSTANTS_HPP

namespace TAXCONSTANTS
{
	const int SIZE = 4;
}

#endif //TAXCONSTANTS