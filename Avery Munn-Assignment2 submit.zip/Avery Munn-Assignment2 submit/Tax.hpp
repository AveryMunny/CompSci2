#ifndef TAX_HPP
#define TAX_HPP
#include "TaxDataType.hpp" //must be included since thr struct taxPayer is defined there
void taxPrint(****)//matches to function in Tax.cpp
void taxTaker(****) //matches to funciton in Tax.cpp

#endif //TAX_HPP
