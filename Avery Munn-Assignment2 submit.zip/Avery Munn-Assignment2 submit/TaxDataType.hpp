#ifndef TAXCONSTANTS_HPP
#define TAXCONSTANTS_HPP

struct taxPayer
{
	float taxRate;
	float income;
	float taxes;
};

#endif //TAXDATATYPE_HPP
