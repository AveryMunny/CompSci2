/*
Avery Munn
Assignemnt 2
acm183@uakron.edu
purpose: STRUCTS
*/

//includes

#include "Tax.hpp"
//Prototype of taxTake and taxPrint are in Tax.hpp, so it must be included

//using
//using std::vector;
//using std::cout;
//using std::cin;

int main()
{
	struct taxPayer numOne;
	struct taxPayer numTwo;

	//calling functions for input and output
	taxTaker(&numOne, &numTwo); //input

	//creating a vector of objects to store info
	//vector <taxPayer> people;
	//people.push_back(numOne);
	//people.push_back(numTwo);

	//outputting
	taxPrint(&numOne, &numTwo); //output
}
